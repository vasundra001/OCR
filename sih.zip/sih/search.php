<?php require_once'assets/include/header.php'?>
<section class="about-sec" id="about">
                <div class="container">
                    <div class="row align-items-center">
                        <h3 align="centre">Your search results</h3>
                        <table class="table table-bordered responsive">
  <thead>
    <tr>
      <th scope="col">Sr. No.</th>
      <th scope="col">Title of document</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      
      <td>1</td>
      <td>OCR DOCUMENT 1</td>
      <td><a href="">View</a></td>
    </tr>
    <tr>
      
      <td>2</td>
      <td>OCR Document 2</td>
      <td><a href="">View</a></td>
    </tr>
  </tbody>
</table>
                    </div>

                    
                </div>
            </section>




<?php require_once'assets/include/footer.php'?>