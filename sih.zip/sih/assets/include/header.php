<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="shortcut icon" href="img/favicon.png" />
        <!--<title itemprop="name">Whiteland Blissville Offers 3 | 4 BHK Luxury Flats Sector 76 Gurgaon</title>-->
		 <title itemprop="name">SIH 2022</title>
        <meta name="description" content="Whiteland Sector 76 Gurugram Offers 3 and 4 Bhk Flats with Luxury amenities, Whiteland Blissville Sector 76 Gurgaon is Located near NH 8. Floor Plan Location" />
        <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet" />
        <link href="../cdn.jsdelivr.net/npm/bootstrap%405.1.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous" />
        <link rel="stylesheet" href="../cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" />
        <link rel="stylesheet" href="css/jquery.fancybox.css" />
        <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

<script>

    $(window).load(function(){

        setTimeout(function() {

                $('#download-brochure').modal('show');

        }, 1000);

            });

</script>


    </head>

    <body>
        <header class="header-area overlay">

    <nav class="navbar navbar-expand-md navbar-dark">

		<div class="container-fluid">

			<a href="index.php" class="navbar-brand">

                <img src="logo.png" alt="" class="logo" height="97px" width="100px">

            </a>

			

			<button type="button" class="navbar-toggler collapsed" data-bs-toggle="collapse" data-bs-target="#main-nav">

				<span class="menu-icon-bar"></span>

				<span class="menu-icon-bar"></span>

				<span class="menu-icon-bar"></span>

			</button>

			

			<div id="main-nav" class="collapse navbar-collapse">

				<ul class="navbar-nav ml-auto">


                    <li><form method="post" action=""><input type="text" name="cname"><input type="submit" value="Search"></form></li>

                    

					

				</ul>

			</div>

		</div>

	</nav>

</header>